<?php

require_once(__DIR__ . '/../../config/db.php');


    $DeleteUserQuery = "DELETE INTO user (id,name,email,password) VALUES (:id, :name, :email, :password)";

    $DeleteStatement = $mysqlClient->prepare($DeleteUserQuery);

    $DeleteStatement->execute();

    header('Location: /admin');

    exit();