<?php

require_once(__DIR__.'/../Views/home.view.php');