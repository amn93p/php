<?php
$title = 'Accueil';
require_once(__DIR__ . '/partials/head.php');
?>

<h1>Page Accueil</h1>

<?php
require_once(__DIR__ . '/partials/footer.php');

?>

