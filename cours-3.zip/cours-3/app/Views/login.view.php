<?php
$title = 'Connexion';
require_once(__DIR__ . '/partials/head.php');
?>

<?php
require_once(__DIR__ . '/partials/footer.php');

?>