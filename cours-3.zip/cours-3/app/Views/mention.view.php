<?php
$title = 'Mentions légales';
require_once(__DIR__ . '/partials/head.php');
?>

<h1>Page Mentions légales</h1>

<?php
require_once(__DIR__ . '/partials/footer.php');

?>

