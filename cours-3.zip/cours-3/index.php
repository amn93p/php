<?php
session_start();

require_once('config/router.php');